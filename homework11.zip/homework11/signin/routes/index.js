var express = require('express');
var router = express.Router();
var validator = require('../public/javascripts/validator');
/* GET detail page. */
var users = {};
router.get('/signup', function(req, res, next) {
    res.render('signup', { title: '注册', user: {} });
});

router.post('/signup', function(req, res, next) {
    var user = req.body
    try {
        checkUser(user);
        req.session.user = user;
        users[user.username] = user;
        res.redirect('/detail');

    } catch (err) {
        res.render('signup', { title: "注册", user: user, error: err.message });
    }
    //res.redirect('/detail');
});

router.all('*', function(req, res, next) {
    req.session.user ? next() : res.redirect('/signin');
});

router.get('/detail', function(req, res, next) {
    res.render('detail', { title: '详情', user: req.session.user });
});

module.exports = router;

function checkUser(user) {
    var errorMessages = [];
    for (var key in user) {
        if (!validator.isFieldValid(key, user[key])) errorMessages.push(validator.form[key].errorMessages);
        if (!validator.isAttrValueUnique(users, user, key)) errorMessages.push(
            "key: " + key + " is not unique by value: " + user[key]
        );
    }
    if (errorMessages.length > 0) throw new Error(errorMessages.join('<br />'));
}