var mongoose = require('mongoose');

var Schema = mongoose.Schema;

// Define User schema 
var userSchema = new Schema({ 
    username: String, 
    password: String, 
    repeatpassword: String, 
    sid: String, 
    phone: String, 
    email: String
});

var User = mongoose.model('User', userSchema);

// export them 
module.exports = User;
