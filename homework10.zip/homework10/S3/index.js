$(document).ready(function() {
    initial(); //初始化整个按钮
    $('#button').mouseleave(function() {
        initial();
    });

    $('.apb').click(function() {
        startRobot();
    });
});

function startRobot() {
    $('#info-bar').attr('status', 'disable');
    getRamdonNum(0);
    getRamdonNum(1);
    getRamdonNum(2);
    getRamdonNum(3);
    getRamdonNum(4);


}

function initial() {
    $('#info-bar').attr('status', 'disable');
    $('.button').attr('status', 'enable').attr('num', 'no');
    $('.unread').html('').hide();
    $('#sum').html('').hide();
}

function getRamdonNum(index_button) {
    $('.button').eq(index_button).find('span').html('...').show();
    var thisButton = $('.button').eq(index_button);
    //miehuoButton(thisButton, 'false');
    $.ajax({
        type: 'POST',
        url: '/',
        success: function(data) {
            if ($('#info-bar').attr('status') == 'disable') {
                $(thisButton).find('span').html(data);
                miehuoButton(thisButton, 'true');
                isgetRes();
            }

        }

    });
}

function miehuoButton(button, flag) {
    if (flag == 'true') {
        $(button).attr('num', 'yes').attr('status', 'disable');

    } else {
        $('.button').attr('status', 'disable');
        $(button).attr('status', 'enable');
    }
}

function isgetRes() {
    var count = 0;
    for (var i = 0; i < 5; i++) {
        if ($('.button').eq(i).attr('num') == 'yes') {
            count++;
        }
    }

    if (count == 5) {
        $("#info-bar").attr('status', 'enable');
        getresult();
    } else {
        $('#info-bar').attr('status', 'disable');
    }
}

function getresult() {
    var result = 0;
    for (var i = 0; i < 5; ++i) {
        result += parseInt($('.button').eq(i).find('span').html());
    }

    $('#sum').html(result).show();
    $('#info-bar').attr('status', 'disable');
}