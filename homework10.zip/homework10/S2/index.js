window.onload = function() { //初始化界面
    initial();
    $('.apb').click(function() {
        //if ($(this).attr('status') == 'enable')
        startRobot();
        //alert(1);
        //}

    });


    $('#button').mouseleave(function() {
        initial();
    });
}

function startRobot() {
    $('#info-bar').attr('status', 'disable');
    getRamdonNum(0);
}


function getRamdonNum(index_button) {
    var thisButton = $('.button').eq(index_button);
    $(thisButton).find('span').show();
    $(thisButton).find('span').text('...');

    $('.button').attr('status', 'disable');
    $(thisButton).attr('status', 'enable');
    $.ajax({
        url: '/',
        method: 'POST',
        headers: {
            'Accept': 'application/json;odata=verbose',
            'X-RequestDigest': $("#__REQUESTDIGEST").val(),
            'x-requestforceauthentication': true,
        },

        success: function(data) {
            if ($('#info-bar').attr('status') == 'disable') {
                //alert(index_button);
                $(thisButton).find('span').text(data);
                $(thisButton).attr('num', 'have');
                $(thisButton).attr('status', 'disable');
                for (var i = index_button + 1; i < 5; i++) {
                    if ($('.button').eq(i).attr('num') == 'no')
                        $('.button').eq(i).attr('status', 'enable');
                }

                if (index_button < 4) {
                    index_button++;
                    getRamdonNum(index_button);
                } else {
                    $('#info-bar').attr('status', 'enable');
                    getresult();
                }
            }

            //isgetRes();
        }

    })
}

function initial() {
    $('.button').attr('status', 'enable') //blue === isclick grey === noclick
    $('#info-bar').attr('status', 'disable') //first sum === noclick
    $('.button').attr('num', 'no');
    $('.unread').hide();
    $('#sum').hide();
}

function isgetRes() {
    var count = 0;
    for (var i = 0; i < 5; i++) {
        if ($('.button').eq(i).attr('num') == 'have')
            count++;
    }

    if (count == 5) {
        $('#info-bar').attr('status', 'enable');
    } else {
        $('#info-bar').attr('status', 'disable');
    }
}

function getresult() {
    var result = 0;
    for (var i = 0; i < 5; ++i) {
        result += parseInt($('.button').eq(i).find('span').html());
    }

    $('#sum').html(result).show();
    $('#info-bar').attr('status', 'disable');
}