$(document).ready(function() {
    initial(); //初始化整个按钮
    $('#button').mouseleave(function() {
        initial();
    });

    $('.apb').click(function() {
        startRobot();
    });
});

var button_array;

function getArray() {
    button_array = new Array();
    while (button_array.length <= 4) {
        var index_button = Math.round(Math.random() * (4 - 0)) + 0;
        var tag = true;
        if (index_button > 4 || index_button < 0) tag = false;
        for (var i = 0; i < button_array.length; i++) {
            if (index_button == button_array[i])
                tag = false;
        }
        if (tag == true)
            button_array.push(index_button);
    }

}



function startRobot() {
    $('#info-bar').attr('status', 'disable');
    getArray();
    count_button = 0;
    getRamdonNum(button_array[0]);
}

function initial() {
    $('#info-bar').attr('status', 'disable');
    $('.button').attr('status', 'enable').attr('num', 'no');
    $('.unread').html('').hide();
    $('#sum').html('').hide();
}
var count_button = 0;

function getRamdonNum(index_button) {

    $('.button').eq(index_button).find('span').html('...').show();
    //count_button++;
    var thisButton = $('.button').eq(index_button);
    miehuoButton(thisButton, 'false');
    $.ajax({
        type: 'POST',
        url: '/',
        success: function(data) {
            if ($('#info-bar').attr('status') == 'disable') {
                $(thisButton).find('span').html(data);
                miehuoButton(thisButton, 'true');
                if (count_button < 4) {
                    count_button++;
                    //var next_button = Math.round(Math.random() * (4 - 0)) + 0;
                    //if (!(next_button <= 4 && next_button >= 0)) alert(next_button);
                    //console.log(next_button);
                    getRamdonNum(button_array[count_button]);
                } else {
                    $('#info-bar').attr('status', 'enable');
                    getresult();
                }
            }

        }

    });


}

function miehuoButton(button, flag) {
    if (flag == 'true') {
        $(button).attr('num', 'yes').attr('status', 'disable');

    } else {
        $('.button').attr('status', 'disable');
        $(button).attr('status', 'enable');
    }
}

function isgetRes() {
    var count = 0;
    for (var i = 0; i < 5; i++) {
        if ($('.button').eq(i).attr('num') == 'yes') {
            count++;
        }
    }

    if (count == 5) {
        $("#info-bar").attr('status', 'enable');
        getresult();
    } else {
        $('#info-bar').attr('status', 'disable');
    }
}

function getresult() {
    var result = 0;
    for (var i = 0; i < 5; ++i) {
        result += parseInt($('.button').eq(i).find('span').html());
    }

    $('#sum').html(result).show();
    $('#info-bar').attr('status', 'disable');
}